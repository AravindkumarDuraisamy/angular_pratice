import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MenuComponent } from './menu/menu.component';
import { MenuService } from './services/menuservice';
import { MenubarModule } from 'primeng/menubar';
import {UserService} from "./services/userservice";
import {AuthService} from "./services/authservice";
import { LoginComponent } from './login/login.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import {MatButtonModule} from '@angular/material/button';
import {MatIconModule} from '@angular/material/icon';
import {MatCardModule} from '@angular/material/card';
import { RegisterComponent } from './register/register.component';
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import 'rxjs'
import {HttpClientModule} from "@angular/common/http";
import { DiamondComponent } from './diamond/diamond.component';
import { ProductComponent } from './product/product.component';
import { SilverComponent } from './silver/silver.component';
import { GoldComponent } from './gold/gold.component';
import {PhotoService} from "./services/photoservice";
import { MatPaginatorModule, MatProgressSpinnerModule, 
  MatSortModule, MatTableModule } from "@angular/material";
import { SavingComponent } from './saving/saving.component';
import { ParentComponent } from './saving/parent/parent.component';
import { ChildComponent } from './saving/child/child.component';
import { ChildtitleComponent } from './saving/childtitle/childtitle.component';




@NgModule({
  declarations: [
    AppComponent,
    MenuComponent,
    LoginComponent,
    RegisterComponent,
    DiamondComponent,
    ProductComponent,
    SilverComponent,
    GoldComponent,
    SavingComponent,
    ParentComponent,
    ChildComponent,
    ChildtitleComponent
  ],
  imports: [
    BrowserModule.withServerTransition({ appId: 'serverApp' }),
    AppRoutingModule,
    MenubarModule,
    BrowserAnimationsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatCardModule,
    MatIconModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    MatTableModule,
    MatPaginatorModule,
    MatProgressSpinnerModule,
    MatSortModule
    

  ],
  providers: [MenuService,UserService,AuthService,PhotoService],
  bootstrap: [AppComponent]
})
export class AppModule { }
