import { Component } from '@angular/core';
import { UserserviceService } from 'projects/tools/src/lib/userservice.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'administration';

  constructor(private userservice:UserserviceService){

  }
}
