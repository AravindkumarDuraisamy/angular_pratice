import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
const PRODUCTS_URL ="http://localhost:4200";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'My-App';
  logopath = './assets/logo.png';
  users:any;
  constructor(private httpClient: HttpClient){}
  ngOnInit(){
    this.httpClient.get(PRODUCTS_URL).subscribe( (data)=> {
      console.log(data);
      this.users = data;
    })
  }
  chkUser(title){
    alert("hai");
    console.log(title);
  }
}
