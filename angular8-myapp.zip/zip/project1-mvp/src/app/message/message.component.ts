import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-message',
  templateUrl: './message.component.html',
  styleUrls: ['./message.component.css']
})
export class MessageComponent implements OnInit {

  
  title = "Kekuran Makuran Jewellery, Dubai Main roadu, Dubai kuruku sandhu, Dubai.";

  @Input() query: string;
  @Input() answer: string;
  
  constructor() { }

  ngOnInit() {
  }

}
