import { TestBed } from '@angular/core/testing';

import { MockhttpinterceptorService } from './mockhttpinterceptor.service';

describe('MockhttpinterceptorService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MockhttpinterceptorService = TestBed.get(MockhttpinterceptorService);
    expect(service).toBeTruthy();
  });
});
