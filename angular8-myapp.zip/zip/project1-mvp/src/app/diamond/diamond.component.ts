import { Component, ViewChild, OnInit } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { PhotoService } from '../services/photoservice';

@Component({
  selector: 'app-diamond',
  templateUrl: './diamond.component.html',
  styleUrls: ['./diamond.component.css']
})

export class DiamondComponent implements OnInit {

  displayedColumns: string[] = ['id', 'title'];

  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;  
	@ViewChild(MatSort, {static: true}) sort: MatSort;
  
  constructor(public photoService:PhotoService) {}

  MyDataSource = new MatTableDataSource();

  ngOnInit() {
    this.photoService.getAllPhotos().subscribe(response=>{        
      this.MyDataSource.data = response;
      this.MyDataSource.sort = this.sort;  
	    this.MyDataSource.paginator = this.paginator; 		           
    });
  }

  applyFilter(filterValue: string) {
    const tableFilters = [];
    tableFilters.push({
      id: 'title',
      value: filterValue
    });


    this.MyDataSource.filter = JSON.stringify(tableFilters);
    if (this.MyDataSource.paginator) {
      this.MyDataSource.paginator.firstPage();
    }
  }

}
