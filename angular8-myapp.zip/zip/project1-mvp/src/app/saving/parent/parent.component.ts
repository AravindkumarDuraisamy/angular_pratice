import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { ChildtitleComponent } from '../childtitle/childtitle.component';
import { ChildComponent } from '../child/child.component';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit, AfterViewInit {



  firstName:string="Aspire System";

  city:string;

  @ViewChild(ChildtitleComponent, {static: false}) childtitleComponent: ChildtitleComponent;
  @ViewChild(ChildComponent, {static: false}) childComponent: ChildComponent;


  constructor() { }

  ngOnInit() {
  }

  ngAfterViewInit(): void{

    console.log(this.childtitleComponent.customerName);
    console.log(this.childComponent.deposit(Math.random()*1000));

  }

  convert(){
    this.city=this.city.toUpperCase();
  }

}
