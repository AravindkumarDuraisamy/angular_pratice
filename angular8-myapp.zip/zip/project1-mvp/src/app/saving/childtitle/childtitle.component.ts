import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-childtitle',
  templateUrl: './childtitle.component.html',
  styleUrls: ['./childtitle.component.css']
})
export class ChildtitleComponent implements OnInit {

  @Input()
  customerName:string;

  constructor() { }

  ngOnInit() {
  }

}
