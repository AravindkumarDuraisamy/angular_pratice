import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {LoginComponent} from "./login/login.component";
import {RegisterComponent} from "./register/register.component";
import {MenuComponent} from "./menu/menu.component";
import {DiamondComponent} from "./diamond/diamond.component";
import {ProductComponent} from "./product/product.component";
import {SilverComponent} from "./silver/silver.component";
import {GoldComponent} from "./gold/gold.component";
import {SavingComponent} from "./saving/saving.component";
import { HomeComponent } from './home/home.component';
import { ContextComponent } from './context/context.component';
import { TestimonialComponent } from './testimonial/testimonial.component';

  
const routes: Routes = [
  {
    path:'Login',
    component:LoginComponent
  },
  { path: 'Register', component: RegisterComponent },
  
  {path:'Menu',component:MenuComponent,
  children: [
    { path: 'Home', component: HomeComponent},
    { path: 'Context', component: ContextComponent },
    { path: 'Testimonial', component: TestimonialComponent },  
   
    { path: 'Saving', component: SavingComponent },
    {path:'Products',component:ProductComponent,

    children: [
        {path:'Diamond',component:DiamondComponent},
        {path:'Silver',component:SilverComponent},
        {path:'Gold',component:GoldComponent}
    ]

  }
  ]
}
  




];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
