import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'userFilter'
})
export class UserPipe implements PipeTransform {

  transform(value: any, letter:string): any {
    //return value.filter(obj=>obj.title.startswith(letter.toUpperCase()));
   // return value.filter(letter);
  }

}
