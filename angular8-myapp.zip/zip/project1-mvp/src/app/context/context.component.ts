import { Component, OnInit } from '@angular/core';
import { CountryService } from "../services/country.service";


@Component({
  selector: 'app-context',
  templateUrl: './context.component.html',
  styleUrls: ['./context.component.css']
})
export class ContextComponent implements OnInit {

  countryNames:any = [];
  population:any = [];

  //segment the data
  slicedCountryNames:any;
  slicedPopulation:any;

  data:any;
  constructor(private countryservice:CountryService) { }

  ngOnInit() {
    this.countryservice.getCountries().subscribe(response => {
      console.log(response);
      response.forEach(obj=>{
        console.log(obj.name +'=>'+ obj.population);
        this.countryNames.push(obj.name);
        this.population.push(obj.population);
      });
      this.slicedCountryNames=this.countryNames.slice(1,200);
      this.slicedPopulation=this.population.slice(1,200);
      this.data = {
        labels:this.slicedCountryNames,
        datasets: [
          {
            label: 'World Population',
            backgroundColor: '#cecece',
            bordercolor: '#000000',
            data: this.slicedPopulation

          }
          
        ]

      }
    })
  }

}
